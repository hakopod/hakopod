# Hakopod UI

An independent design-system package based on shadcn/ui composition patterns: Radix behavior, `asChild` slots, class-variance-authority variants, and CSS semantic tokens. The Hakopod dashboard imports these source components through `@hakopod/ui`; this package has no application data, router, query cache, or orchestration code.

The Open Port brand comes from Hakopod's supplied identity kit. Ink, Paper, Ion, Forest and Fog are preserved. Space Grotesk is self-hosted; its SIL Open Font License is included in `assets/OFL.txt`. Keep the logo in a single solid color, with its eight blocks and open center intact.

## Consume

```tsx
import { Button, Card, Badge, Tooltip, Dialog, BrandMark } from "@hakopod/ui";
import "@hakopod/ui/styles.css";
```

Import `tokens.css` before application overrides. Dark is the default; set `data-theme="light"` on the document for light mode. Interactive components provide keyboard focus, reduced-motion handling and high-contrast support. Tooltips also appear on keyboard focus; all icon-only controls still need an accessible name.

The package intentionally has no runtime build step, chart framework, animation engine or editor. The consuming Vite/TypeScript build compiles the TSX. Primitive CSS lives here; dashboard layouts remain in the application.

Source lives at [hakopod/hakopod-design-system](https://github.com/hakopod/hakopod-design-system), with the dashboard in [hakopod/hakopod](https://github.com/hakopod/hakopod). The dashboard tracks this repository as its `packages/ui` submodule. Initialize it with `git submodule update --init packages/ui` from the dashboard checkout. The dashboard also includes a checksummed source snapshot for builds without submodule access; see its [submodule guide](https://github.com/hakopod/hakopod/blob/main/docs/submodules.md).
