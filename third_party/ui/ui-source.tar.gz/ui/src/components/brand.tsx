export function BrandMark({
  size = 30,
  className,
}: {
  size?: number;
  className?: string;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 96 96"
      fill="currentColor"
      aria-hidden="true"
      className={className}
    >
      <rect x="42" y="6" width="12" height="36" rx="1.5" />
      <rect x="42" y="54" width="12" height="36" rx="1.5" />
      <rect x="18" y="18" width="12" height="24" rx="1.5" />
      <rect x="18" y="54" width="12" height="24" rx="1.5" />
      <rect x="66" y="18" width="12" height="24" rx="1.5" />
      <rect x="66" y="54" width="12" height="24" rx="1.5" />
      <rect x="6" y="42" width="12" height="12" rx="1.5" />
      <rect x="78" y="42" width="12" height="12" rx="1.5" />
    </svg>
  );
}
