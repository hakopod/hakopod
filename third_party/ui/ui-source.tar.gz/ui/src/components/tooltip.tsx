import * as Primitive from "@radix-ui/react-tooltip";
import type { ReactNode } from "react";
export function Tooltip({
  children,
  content,
  side = "right",
}: {
  children: ReactNode;
  content: ReactNode;
  side?: "top" | "right" | "bottom" | "left";
}) {
  return (
    <Primitive.Provider delayDuration={250}>
      <Primitive.Root>
        <Primitive.Trigger asChild>{children}</Primitive.Trigger>
        <Primitive.Portal>
          <Primitive.Content className="ui-tooltip" side={side} sideOffset={10}>
            {content}
            <Primitive.Arrow className="ui-tooltip-arrow" />
          </Primitive.Content>
        </Primitive.Portal>
      </Primitive.Root>
    </Primitive.Provider>
  );
}
