"use client";

import type { ReactNode } from "react";
import * as Dropdown from "@radix-ui/react-dropdown-menu";
import { cn } from "@hakopod/hatch-ui/lib/utils";
import { Brackets } from "@hakopod/hatch-ui/components/brackets";

export function Menu({
  trigger,
  children,
  className,
  align = "end",
}: {
  trigger: ReactNode;
  children: ReactNode;
  className?: string;
  align?: "start" | "end";
}) {
  return (
    <Dropdown.Root>
      <Dropdown.Trigger asChild>{trigger}</Dropdown.Trigger>
      <Dropdown.Portal>
        <Dropdown.Content
          align={align}
          sideOffset={10}
          collisionPadding={14}
          className={cn("dropdown-content", className)}
        >
          {children}
        </Dropdown.Content>
      </Dropdown.Portal>
    </Dropdown.Root>
  );
}

export function MenuItem({
  children,
  onSelect,
  destructive,
  disabled,
}: {
  children: ReactNode;
  onSelect?: () => void;
  destructive?: boolean;
  disabled?: boolean;
}) {
  return (
    <Dropdown.Item
      onSelect={onSelect}
      disabled={disabled}
      className={cn("menu-item interactive", destructive && "error")}
    >
      {children}
      <Brackets />
    </Dropdown.Item>
  );
}
export const MenuSeparator = () => (
  <Dropdown.Separator className="menu-separator" />
);

export const DropdownMenu = Dropdown.Root;
export const DropdownMenuTrigger = Dropdown.Trigger;
export const DropdownMenuGroup = Dropdown.Group;
export const DropdownMenuLabel = Dropdown.Label;
export const DropdownMenuItem = MenuItem;
export const DropdownMenuSeparator = MenuSeparator;
