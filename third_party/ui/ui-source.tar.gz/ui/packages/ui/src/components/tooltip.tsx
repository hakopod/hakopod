"use client";
import type { ComponentProps } from "react";
import * as Primitive from "@radix-ui/react-tooltip";
import { cn } from "@hakopod/hatch-ui/lib/utils";
export const TooltipProvider = Primitive.Provider;
export const Tooltip = Primitive.Root;
export const TooltipTrigger = Primitive.Trigger;
export function TooltipContent({
  className,
  sideOffset = 9,
  ...props
}: ComponentProps<typeof Primitive.Content>) {
  return (
    <Primitive.Portal>
      <Primitive.Content
        className={cn("tooltip", className)}
        sideOffset={sideOffset}
        {...props}
      />
    </Primitive.Portal>
  );
}
