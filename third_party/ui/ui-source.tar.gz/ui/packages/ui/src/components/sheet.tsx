"use client";
import { forwardRef, type ComponentProps } from "react";
import { DialogContent } from "@hakopod/hatch-ui/components/dialog";
import {
  DialogPanel,
  type DialogPanelProps,
} from "@hakopod/hatch-ui/components/dialog-panel";
export {
  Dialog as Sheet,
  DialogTrigger as SheetTrigger,
  DialogClose as SheetClose,
  DialogHeader as SheetHeader,
  DialogBody as SheetBody,
  DialogFooter as SheetFooter,
  DialogTitle as SheetTitle,
  DialogDescription as SheetDescription,
} from "@hakopod/hatch-ui/components/dialog";
export const SheetContent = forwardRef<
  HTMLDivElement,
  ComponentProps<typeof DialogContent>
>(function SheetContent(props, ref) {
  return <DialogContent ref={ref} sheet {...props} />;
});
export function SheetPanel(props: Omit<DialogPanelProps, "sheet">) {
  return <DialogPanel {...props} sheet />;
}
