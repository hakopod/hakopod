"use client";

import { useId, type ComponentProps } from "react";
import * as Primitive from "@radix-ui/react-checkbox";
import { Check, Minus } from "lucide-react";
import { Brackets } from "@hakopod/hatch-ui/components/brackets";

export function CheckField({
  label,
  checked,
  onCheckedChange,
  disabled,
}: {
  label: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  disabled?: boolean;
}) {
  const id = useId();
  return (
    <div className="check-field">
      <Primitive.Root
        id={id}
        className="checkbox interactive"
        checked={checked}
        onCheckedChange={(value) => onCheckedChange(value === true)}
        disabled={disabled}
      >
        <Primitive.Indicator>
          <Check size={12} strokeWidth={2.5} />
        </Primitive.Indicator>
        <Brackets />
      </Primitive.Root>
      <label htmlFor={id}>{label}</label>
    </div>
  );
}

export function Checkbox({
  className = "",
  ...props
}: ComponentProps<typeof Primitive.Root>) {
  return (
    <Primitive.Root className={`checkbox interactive ${className}`} {...props}>
      <Primitive.Indicator>
        <Check size={12} className="checkbox-check" />
        <Minus size={12} className="checkbox-minus" />
      </Primitive.Indicator>
      <Brackets />
    </Primitive.Root>
  );
}
