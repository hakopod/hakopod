"use client";
import { forwardRef, type InputHTMLAttributes } from "react";
import { Brackets } from "@hakopod/hatch-ui/components/brackets";
import { cn } from "@hakopod/hatch-ui/lib/utils";
export const Input = forwardRef<
  HTMLInputElement,
  InputHTMLAttributes<HTMLInputElement> & { containerClassName?: string }
>(function Input({ containerClassName, ...props }, ref) {
  return (
    <div className={cn("input-wrap", containerClassName)}>
      <input ref={ref} {...props} />
      <Brackets bold />
    </div>
  );
});
