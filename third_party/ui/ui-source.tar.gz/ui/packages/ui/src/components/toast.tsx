"use client";
import { useEffect } from "react";
import { CircleCheck, CircleAlert, X } from "lucide-react";
import { IconButton } from "@hakopod/hatch-ui/components/icon-button";
export function Toast({
  open,
  onOpenChange,
  message,
  duration = 4000,
  destructive = false,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  message: string;
  duration?: number;
  destructive?: boolean;
}) {
  useEffect(() => {
    if (!open || duration <= 0) return;
    const timer = setTimeout(() => onOpenChange(false), duration);
    return () => clearTimeout(timer);
  }, [open, duration, onOpenChange]);
  if (!open) return null;
  return (
    <div
      className={`toast ${destructive ? "toast-error" : ""}`}
      role={destructive ? "alert" : "status"}
    >
      {destructive ? <CircleAlert /> : <CircleCheck />}
      <span>{message}</span>
      <IconButton
        label="Dismiss notification"
        onClick={() => onOpenChange(false)}
      >
        <X />
      </IconButton>
    </div>
  );
}
