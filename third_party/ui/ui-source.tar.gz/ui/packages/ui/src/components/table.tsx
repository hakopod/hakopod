import type { ComponentProps } from "react";
import { cn } from "@hakopod/hatch-ui/lib/utils";
export function Table({ className, ...props }: ComponentProps<"table">) {
  return (
    <div className="table-wrap">
      <table className={cn("ui-table", className)} {...props} />
    </div>
  );
}
export function TableHeader(props: ComponentProps<"thead">) {
  return <thead {...props} />;
}
export function TableBody(props: ComponentProps<"tbody">) {
  return <tbody {...props} />;
}
export function TableRow(props: ComponentProps<"tr">) {
  return <tr {...props} />;
}
export function TableHead(props: ComponentProps<"th">) {
  return <th scope="col" {...props} />;
}
export function TableCell(props: ComponentProps<"td">) {
  return <td {...props} />;
}
export function TableCaption(props: ComponentProps<"caption">) {
  return <caption {...props} />;
}
