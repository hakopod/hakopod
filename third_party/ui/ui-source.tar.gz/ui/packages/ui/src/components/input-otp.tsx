"use client";
import { OTPInput, REGEXP_ONLY_DIGITS } from "input-otp";
import { Brackets } from "@hakopod/hatch-ui/components/brackets";

export function InputOTP({
  value,
  onChange,
  length = 6,
  label = "Verification code",
  disabled = false,
}: {
  value: string;
  onChange: (value: string) => void;
  length?: number;
  label?: string;
  disabled?: boolean;
}) {
  const count = Number.isFinite(length)
    ? Math.min(12, Math.max(1, Math.floor(length)))
    : 6;
  return (
    <OTPInput
      value={value}
      onChange={onChange}
      maxLength={count}
      pattern={REGEXP_ONLY_DIGITS}
      inputMode="numeric"
      autoComplete="one-time-code"
      aria-label={label}
      disabled={disabled}
      containerClassName="ui-otp"
      render={({ slots }) =>
        slots.map((slot, index) => (
          <div
            className="otp-cell"
            data-active={slot.isActive || undefined}
            data-disabled={disabled || undefined}
            key={index}
            aria-hidden="true"
          >
            <span>{slot.char}</span>
            {slot.hasFakeCaret && <span className="otp-caret" />}
            <Brackets bold />
          </div>
        ))
      }
    />
  );
}
