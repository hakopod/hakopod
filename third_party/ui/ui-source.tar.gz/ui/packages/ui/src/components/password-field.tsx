"use client";

import { useId, useState, type InputHTMLAttributes } from "react";
import { Eye, EyeOff } from "lucide-react";
import { Brackets } from "@hakopod/hatch-ui/components/brackets";
import { IconButton } from "@hakopod/hatch-ui/components/icon-button";

export function PasswordField({
  label = "Password",
  error,
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { label?: string; error?: string }) {
  const [visible, setVisible] = useState(false);
  const id = useId();
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <div className="input-wrap password-wrap">
        <input
          {...props}
          id={id}
          type={visible ? "text" : "password"}
          aria-invalid={!!error}
          aria-describedby={error ? `${id}-error` : undefined}
        />
        <IconButton
          label={visible ? "Hide password" : "Show password"}
          onClick={() => setVisible(!visible)}
        >
          {visible ? <EyeOff /> : <Eye />}
        </IconButton>
        <Brackets bold />
      </div>
      {error && (
        <p id={`${id}-error`} className="field-help error" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}
