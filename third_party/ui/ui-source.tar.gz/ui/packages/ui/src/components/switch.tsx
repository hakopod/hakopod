"use client";

import { useId, type ComponentProps } from "react";
import * as Primitive from "@radix-ui/react-switch";

export function SwitchField({
  label,
  checked,
  onCheckedChange,
}: {
  label: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
}) {
  const id = useId();
  return (
    <div className="switch-field">
      <Primitive.Root
        id={id}
        className="switch"
        checked={checked}
        onCheckedChange={onCheckedChange}
      >
        <Primitive.Thumb className="switch-thumb" />
      </Primitive.Root>
      <label htmlFor={id}>{label}</label>
    </div>
  );
}

export function Switch({
  className = "",
  ...props
}: ComponentProps<typeof Primitive.Root>) {
  return (
    <Primitive.Root className={`switch ${className}`} {...props}>
      <Primitive.Thumb className="switch-thumb" />
    </Primitive.Root>
  );
}
