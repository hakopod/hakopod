import type { HTMLAttributes } from "react";
import {
  Circle,
  CircleAlert,
  CircleCheck,
  CircleX,
  LoaderCircle,
} from "lucide-react";
import { cn } from "@hakopod/hatch-ui/lib/utils";
export type StatusTone =
  "success" | "running" | "warning" | "error" | "neutral";
const icons = {
  success: CircleCheck,
  running: LoaderCircle,
  warning: CircleAlert,
  error: CircleX,
  neutral: Circle,
};
export function Status({
  tone = "neutral",
  children,
  className,
  ...props
}: HTMLAttributes<HTMLSpanElement> & { tone?: StatusTone }) {
  const Icon = icons[tone];
  return (
    <span
      className={cn("ui-status", `ui-status-${tone}`, className)}
      {...props}
    >
      <Icon
        aria-hidden="true"
        className={tone === "running" ? "spin" : undefined}
      />
      {children}
    </span>
  );
}
