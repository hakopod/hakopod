"use client";
import type { ReactNode } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogBody,
  DialogFooter,
} from "@hakopod/hatch-ui/components/dialog";
export type DialogPanelProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: ReactNode;
  breadcrumb?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  className?: string;
  sheet?: boolean;
};
export function DialogPanel({
  open,
  onOpenChange,
  title,
  description,
  breadcrumb,
  children,
  footer,
  className,
  sheet,
}: DialogPanelProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className={className}
        sheet={sheet}
        closeLabel={`Close ${title}`}
      >
        <DialogHeader>
          {breadcrumb && <div className="steps">{breadcrumb}</div>}
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription
            className={description ? "dialog-description" : "sr-only"}
          >
            {description || `${title} options`}
          </DialogDescription>
        </DialogHeader>
        <DialogBody>{children}</DialogBody>
        {footer && <DialogFooter>{footer}</DialogFooter>}
      </DialogContent>
    </Dialog>
  );
}
export const Modal = DialogPanel;
