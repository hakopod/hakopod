"use client";
import {
  createContext,
  forwardRef,
  useContext,
  useRef,
  type ComponentProps,
  type HTMLAttributes,
} from "react";
import * as Primitive from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { Brackets } from "@hakopod/hatch-ui/components/brackets";
import { Button } from "@hakopod/hatch-ui/components/button";
import { cn } from "@hakopod/hatch-ui/lib/utils";
const Depth = createContext(0);
export function Dialog(props: ComponentProps<typeof Primitive.Root>) {
  const depth = useContext(Depth);
  return (
    <Depth.Provider value={depth + 1}>
      <Primitive.Root {...props} />
    </Depth.Provider>
  );
}
export const DialogTrigger = Primitive.Trigger;
export const DialogClose = Primitive.Close;
export const DialogTitle = Primitive.Title;
export const DialogDescription = Primitive.Description;
export const DialogContent = forwardRef<
  HTMLDivElement,
  ComponentProps<typeof Primitive.Content> & {
    sheet?: boolean;
    closeLabel?: string;
    showCloseButton?: boolean;
  }
>(function DialogContent(
  {
    children,
    className,
    sheet,
    closeLabel = "Close dialog",
    showCloseButton = true,
    onOpenAutoFocus,
    onCloseAutoFocus,
    style,
    ...props
  },
  forwardedRef,
) {
  const depth = Math.max(0, useContext(Depth) - 1);
  const opener = useRef<HTMLElement | null>(null);
  const content = useRef<HTMLDivElement | null>(null);
  return (
    <Primitive.Portal>
      <Primitive.Overlay
        className="dialog-overlay"
        style={{ zIndex: 40 + depth * 20 }}
      />
      <Primitive.Content
        ref={(node) => {
          content.current = node;
          if (typeof forwardedRef === "function") forwardedRef(node);
          else if (forwardedRef) forwardedRef.current = node;
        }}
        className={cn("dialog-content", sheet && "sheet", className)}
        style={{ zIndex: 50 + depth * 20, ...style }}
        onOpenAutoFocus={(event) => {
          opener.current =
            document.activeElement instanceof HTMLElement
              ? document.activeElement
              : null;
          onOpenAutoFocus?.(event);
          if (!event.defaultPrevented) {
            const input = content.current?.querySelector<HTMLInputElement>(
              "input:not([type=hidden]):not([disabled])",
            );
            if (input) {
              event.preventDefault();
              input.focus();
            }
          }
        }}
        onCloseAutoFocus={(event) => {
          onCloseAutoFocus?.(event);
          if (
            !event.defaultPrevented &&
            opener.current?.isConnected &&
            opener.current !== document.body
          ) {
            event.preventDefault();
            opener.current.focus();
          }
        }}
        {...props}
      >
        <Brackets bold />
        {children}
        {showCloseButton && (
          <Primitive.Close asChild>
            <Button
              variant="ghost"
              size="icon"
              className="dialog-close"
              aria-label={closeLabel}
            >
              <X />
            </Button>
          </Primitive.Close>
        )}
      </Primitive.Content>
    </Primitive.Portal>
  );
});
export function DialogHeader({
  className,
  ...props
}: HTMLAttributes<HTMLElement>) {
  return <header className={cn("dialog-header", className)} {...props} />;
}
export function DialogBody({
  className,
  ...props
}: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("dialog-body", className)} {...props} />;
}
export function DialogFooter({
  className,
  ...props
}: HTMLAttributes<HTMLElement>) {
  return <footer className={cn("dialog-footer", className)} {...props} />;
}
