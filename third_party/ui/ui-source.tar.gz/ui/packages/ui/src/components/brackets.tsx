"use client";

import { cn } from "@hakopod/hatch-ui/lib/utils";

export function Brackets({ bold = false }: { bold?: boolean }) {
  return (
    <span
      aria-hidden="true"
      className={cn("brackets", bold && "brackets-bold")}
    >
      <i />
      <i />
      <i />
      <i />
    </span>
  );
}
