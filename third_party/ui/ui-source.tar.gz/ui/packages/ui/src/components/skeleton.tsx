import type { HTMLAttributes } from "react";
import { cn } from "@hakopod/hatch-ui/lib/utils";
export function Skeleton({
  className,
  ...props
}: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      aria-hidden="true"
      className={cn("ui-skeleton hatch", className)}
      {...props}
    />
  );
}
