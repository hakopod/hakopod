"use client";

import { forwardRef, type ButtonHTMLAttributes } from "react";
import { Slot, Slottable } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@hakopod/hatch-ui/lib/utils";
import { Brackets } from "@hakopod/hatch-ui/components/brackets";

export const buttonVariants = cva("button interactive", {
  variants: {
    variant: {
      primary: "button-primary",
      secondary: "button-secondary",
      outline: "button-outline",
      ghost: "button-ghost",
      destructive: "button-destructive",
      chip: "button-chip",
    },
    size: {
      sm: "button-sm",
      md: "button-md",
      lg: "button-lg",
      icon: "button-icon",
    },
  },
  defaultVariants: { variant: "primary", size: "md" },
});

export const Button = forwardRef<
  HTMLButtonElement,
  ButtonHTMLAttributes<HTMLButtonElement> &
    VariantProps<typeof buttonVariants> & { asChild?: boolean }
>(function Button(
  { className, variant, size, children, asChild, ...props },
  ref,
) {
  const Component = asChild ? Slot : "button";
  return (
    <Component
      ref={ref}
      type={asChild ? undefined : "button"}
      className={cn(buttonVariants({ variant, size }), className)}
      {...props}
    >
      <Slottable>{children}</Slottable>
      <Brackets />
    </Component>
  );
});
