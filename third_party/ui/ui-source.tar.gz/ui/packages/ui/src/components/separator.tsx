import type { HTMLAttributes } from "react";
import { cn } from "@hakopod/hatch-ui/lib/utils";
export function Separator({
  orientation = "horizontal",
  className,
  ...props
}: HTMLAttributes<HTMLDivElement> & {
  orientation?: "horizontal" | "vertical";
}) {
  return (
    <div
      role="separator"
      aria-orientation={orientation}
      className={cn("ui-separator", className)}
      {...props}
    />
  );
}
