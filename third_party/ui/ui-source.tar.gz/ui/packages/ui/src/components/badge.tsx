"use client";

import type { ReactNode } from "react";
import { cn } from "@hakopod/hatch-ui/lib/utils";

export function Badge({
  children,
  tone,
}: {
  children: ReactNode;
  tone?: string;
}) {
  return (
    <span className={cn("badge", tone && `badge-${tone}`)}>{children}</span>
  );
}
