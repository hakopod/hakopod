"use client";
import { forwardRef, type TextareaHTMLAttributes } from "react";
import { Brackets } from "@hakopod/hatch-ui/components/brackets";
import { cn } from "@hakopod/hatch-ui/lib/utils";
export const Textarea = forwardRef<
  HTMLTextAreaElement,
  TextareaHTMLAttributes<HTMLTextAreaElement> & { containerClassName?: string }
>(function Textarea({ containerClassName, ...props }, ref) {
  return (
    <div className={cn("input-wrap", containerClassName)}>
      <textarea ref={ref} {...props} />
      <Brackets bold />
    </div>
  );
});
