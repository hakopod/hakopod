"use client";

import { useId, type InputHTMLAttributes, type ReactNode } from "react";
import { cn } from "@hakopod/hatch-ui/lib/utils";
import { Brackets } from "@hakopod/hatch-ui/components/brackets";

export function Field({
  label,
  error,
  help,
  trailing,
  ...props
}: InputHTMLAttributes<HTMLInputElement> & {
  label: string;
  error?: string;
  help?: ReactNode;
  trailing?: ReactNode;
}) {
  const generated = useId();
  const id = props.id || generated;
  return (
    <div className="field">
      <div className="field-heading">
        <label htmlFor={id}>{label}</label>
        {trailing}
      </div>
      <div className="input-wrap">
        <input
          {...props}
          id={id}
          aria-invalid={!!error}
          aria-describedby={error || help ? `${id}-help` : undefined}
        />
        <Brackets bold />
      </div>
      {(error || help) && (
        <div
          id={`${id}-help`}
          className={cn("field-help", error && "error")}
          role={error ? "alert" : undefined}
        >
          {error || help}
        </div>
      )}
    </div>
  );
}
