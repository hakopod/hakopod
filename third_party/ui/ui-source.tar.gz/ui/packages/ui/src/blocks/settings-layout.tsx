import type { ReactNode } from "react";
export type SettingsSection = { id: string; label: string; group?: string };
export function SettingsLayout({
  sections,
  active,
  onSectionChange,
  children,
  label = "Settings sections",
}: {
  sections: SettingsSection[];
  active: string;
  onSectionChange: (id: string) => void;
  children: ReactNode;
  label?: string;
}) {
  return (
    <div className="settings-layout">
      <nav className="settings-nav" aria-label={label}>
        {sections.map((section, index) => (
          <div key={section.id}>
            {section.group && section.group !== sections[index - 1]?.group && (
              <div className="nav-group">{section.group}</div>
            )}
            <button
              type="button"
              data-active={active === section.id}
              aria-current={active === section.id ? "page" : undefined}
              onClick={() => onSectionChange(section.id)}
            >
              {section.label}
            </button>
          </div>
        ))}
      </nav>
      <div className="settings-content">{children}</div>
    </div>
  );
}
