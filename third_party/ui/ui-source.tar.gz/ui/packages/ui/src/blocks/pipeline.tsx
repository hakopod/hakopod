import { Fragment } from "react";
import { Brackets } from "@hakopod/hatch-ui/components/brackets";
import { Status, type StatusTone } from "@hakopod/hatch-ui/components/status";
export type PipelineStage = {
  id: string;
  label: string;
  description: string;
  state: StatusTone;
  duration?: string;
};
export function Pipeline({
  stages,
  active,
  onStageChange,
}: {
  stages: PipelineStage[];
  active: string;
  onStageChange: (id: string) => void;
}) {
  return (
    <div className="pipeline" aria-label="Pipeline stages">
      {stages.map((stage, index) => (
        <Fragment key={stage.id}>
          <button
            className={`pipeline-stage interactive ${stage.state === "running" ? "hatch" : ""}`}
            data-active={active === stage.id}
            type="button"
            aria-label={`Inspect ${stage.label} stage`}
            aria-pressed={active === stage.id}
            onClick={() => onStageChange(stage.id)}
          >
            <Brackets />
            <div className="stage-heading">
              <Status tone={stage.state}>{stage.label}</Status>
              {stage.duration && (
                <span className="duration">{stage.duration}</span>
              )}
            </div>
            <p>{stage.description}</p>
          </button>
          {index < stages.length - 1 && (
            <span className="stage-line" aria-hidden="true" />
          )}
        </Fragment>
      ))}
    </div>
  );
}
