import type { ReactNode } from "react";
import { Brackets } from "@hakopod/hatch-ui/components/brackets";

export function EmptyState({
  title,
  description,
  children,
}: {
  title: string;
  description: string;
  children?: ReactNode;
}) {
  return (
    <div className="empty-canvas bg-grid">
      <section className="empty-card">
        <Brackets bold />
        <h1>{title}</h1>
        <p>{description}</p>
        <div className="empty-actions">{children}</div>
      </section>
    </div>
  );
}
