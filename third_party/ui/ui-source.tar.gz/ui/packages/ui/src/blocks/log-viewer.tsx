"use client";
import { useState } from "react";
import { Copy, Download, Search } from "lucide-react";
import { IconButton } from "@hakopod/hatch-ui/components/icon-button";
import { SwitchField } from "@hakopod/hatch-ui/components/switch";
import { Input } from "@hakopod/hatch-ui/components/input";
export type LogLine = {
  id: string;
  timestamp: string;
  level: "debug" | "info" | "warn" | "error";
  message: string;
};
export function LogViewer({
  entries,
  onSelect,
  onCopy,
  onDownload,
  label = "Logs",
}: {
  entries: LogLine[];
  onSelect?: (entry: LogLine) => void;
  onCopy?: (entries: LogLine[]) => void;
  onDownload?: (entries: LogLine[]) => void;
  label?: string;
}) {
  const [query, setQuery] = useState("");
  const [wrap, setWrap] = useState(true);
  const filtered = entries.filter((entry) =>
    `${entry.level} ${entry.message}`
      .toLowerCase()
      .includes(query.toLowerCase()),
  );
  return (
    <section className="ui-log-viewer" aria-label={label}>
      <div className="ui-log-toolbar">
        <Search />
        <Input
          aria-label={`Search ${label.toLowerCase()}`}
          placeholder="Search logs…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <span className="spacer" />
        {onCopy && (
          <IconButton
            label="Copy filtered logs"
            onClick={() => onCopy(filtered)}
          >
            <Copy />
          </IconButton>
        )}
        {onDownload && (
          <IconButton
            label="Download filtered logs"
            onClick={() => onDownload(filtered)}
          >
            <Download />
          </IconButton>
        )}
        <SwitchField label="Wrap" checked={wrap} onCheckedChange={setWrap} />
      </div>
      <div className={`log-lines ${wrap ? "wrap" : ""}`}>
        {filtered.slice(-200).map((entry) => (
          <button
            type="button"
            key={entry.id}
            className="log-line"
            onClick={() => onSelect?.(entry)}
          >
            <time className="log-time">{entry.timestamp}</time>
            <span className={`level-${entry.level}`}>{entry.level}</span>
            <span className="log-message">{entry.message}</span>
          </button>
        ))}
        {!filtered.length && (
          <p className="ui-log-empty">No matching log entries.</p>
        )}
      </div>
    </section>
  );
}
