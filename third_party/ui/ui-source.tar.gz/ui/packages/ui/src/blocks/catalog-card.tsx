import type { ButtonHTMLAttributes } from "react";
import { Badge } from "@hakopod/hatch-ui/components/badge";
import { Brackets } from "@hakopod/hatch-ui/components/brackets";
import { cn } from "@hakopod/hatch-ui/lib/utils";
export type CatalogCardProps = Omit<
  ButtonHTMLAttributes<HTMLButtonElement>,
  "title"
> & {
  title: string;
  category: string;
  slug: string;
  version: string;
  description: string;
  instances?: number;
};
export function CatalogCard({
  title,
  category,
  slug,
  version,
  description,
  instances = 0,
  className,
  ...props
}: CatalogCardProps) {
  return (
    <button
      type="button"
      className={cn("catalog-card interactive", className)}
      {...props}
    >
      <Brackets />
      <div className="catalog-card-header">
        <h2>{title}</h2>
        <Badge>{category}</Badge>
      </div>
      <p className="catalog-slug">
        {slug} / v{version}
      </p>
      <p className="catalog-description">{description}</p>
      <span className="catalog-count">
        {instances} {instances === 1 ? "instance" : "instances"}
      </span>
    </button>
  );
}
