import type { ReactNode } from "react";
import { Brackets } from "@hakopod/hatch-ui/components/brackets";
export function AuthCard({
  title,
  children,
  footer,
  className = "",
}: {
  title: string;
  children: ReactNode;
  footer?: ReactNode;
  className?: string;
}) {
  return (
    <section className={`auth-card ${className}`}>
      <Brackets bold />
      <header>
        <h1>{title}</h1>
      </header>
      <div className="auth-body">{children}</div>
      {footer && <footer>{footer}</footer>}
    </section>
  );
}
